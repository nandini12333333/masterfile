package com.authentication.model;

public enum ERole {
	
	USER,
	ADMIN

}
